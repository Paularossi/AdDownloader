"""Top-level package for AdDownloader."""
# AdDownloader/__init__.py
# import classes and methods from the package as a whole

__app_name__ = "AdDownloader"
__version__ = "0.2.9"

# license retrieved from: https://choosealicense.com/licenses/gpl-3.0/#